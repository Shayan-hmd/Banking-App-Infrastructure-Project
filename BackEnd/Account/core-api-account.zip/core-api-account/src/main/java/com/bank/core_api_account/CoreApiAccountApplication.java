package com.bank.core_api_account;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoreApiAccountApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoreApiAccountApplication.class, args);
	}

}
